﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace PerfectPopup
{
    public static class ViewExtension
    {
        public static IEnumerable<View> GetAllChildren(this VisualElement source)
        {
            if (source != null)
            {
                ContentView contentView = source as ContentView;
                if (contentView != null)
                {
                    yield return contentView.Content;
                    foreach (View view in contentView.GetAllChildren())
                        yield return view;

                }
                else
                {
                    Layout<View> viewLayout = source as Layout<View>;
                    if (viewLayout != null)
                    {
                        foreach (View child in viewLayout.Children)
                        {
                            yield return child;
                            foreach (View view in child.GetAllChildren())
                                yield return view;
                        }
                    }
                    else
                    {
                        ContentPage contentPage = source as ContentPage;
                        if (contentPage != null)
                        {
                            yield return contentPage.Content;
                            foreach (View view in contentPage.Content.GetAllChildren())
                                yield return view;
                        }
                    }
                }
            }
        }
    }
}

